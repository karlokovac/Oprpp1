package hr.fer.oprpp1.custom.collections.demo;

public class InvalidExpressionException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}
