package hr.fer.oprpp1.custom.scripting.lexer;

/**
 * Enumeration of possible states during lexical analysis
 */
public enum ScriptLexerState {
	BASIC, EXTENDED
}
