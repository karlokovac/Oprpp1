package hr.fer.oprpp1.hw02.prob1;

/**
 * Enumeration modeling possible types of tokens
 */
public enum TokenType {
	EOF, WORD, NUMBER, SYMBOL
}
