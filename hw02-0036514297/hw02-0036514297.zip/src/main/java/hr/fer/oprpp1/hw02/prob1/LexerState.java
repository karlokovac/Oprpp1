package hr.fer.oprpp1.hw02.prob1;

/**
 * Enumeration of possible states during lexical analysis
 */
public enum LexerState {
	BASIC, EXTENDED
}
