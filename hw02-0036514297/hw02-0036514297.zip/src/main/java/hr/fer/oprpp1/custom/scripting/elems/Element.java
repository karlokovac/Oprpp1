package hr.fer.oprpp1.custom.scripting.elems;

public class Element {

	public String asText() {
		return String.valueOf("");
	}
}
