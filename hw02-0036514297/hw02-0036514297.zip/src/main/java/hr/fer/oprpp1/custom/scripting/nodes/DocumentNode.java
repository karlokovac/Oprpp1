package hr.fer.oprpp1.custom.scripting.nodes;

public class DocumentNode extends Node {

}
